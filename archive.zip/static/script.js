console.log("Bank app loaded");

