console.log("ScotiTrust loaded");
